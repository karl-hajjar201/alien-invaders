"""
Subcontroller module for Alien Invaders

This module contains the subcontroller to manage a single level or wave in the Alien
Invaders game.  Instances of Wave represent a single wave.  Whenever you move to a
new level, you are expected to make a new instance of the class.

The subcontroller Wave manages the ship, the aliens and any laser bolts on screen.
These are model objects.  Their classes are defined in models.py.

Most of your work on this assignment will be in either this module or models.py.
Whether a helper method belongs in this module or models.py is often a complicated
issue.  If you do not know, ask on Piazza and we will answer.

# Leo Tong/ Karl Hajjar (llt49) (ksh82)
# 12/4/18
"""
from game2d import *
from consts import *
from models import *
import random

# PRIMARY RULE: Wave can only access attributes in models.py via getters/setters
# Wave is NOT allowed to access anything in app.py (Subcontrollers are not permitted
# to access anything in their parent. To see why, take CS 3152)


class Wave(object):
    """
    This class controls a single level or wave of Alien Invaders.

    This subcontroller has a reference to the ship, aliens, and any laser bolts on screen.
    It animates the laser bolts, removing any aliens as necessary. It also marches the
    aliens back and forth across the screen until they are all destroyed or they reach
    the defense line (at which point the player loses). When the wave is complete, you
    should create a NEW instance of Wave (in Invaders) if you want to make a new wave of
    aliens.

    If you want to pause the game, tell this controller to draw, but do not update.  See
    subcontrollers.py from Lecture 24 for an example.  This class will be similar to
    than one in how it interacts with the main class Invaders.
    INSTANCE ATTRIBUTES:
        _ship:   the player ship to control [Ship]
        _aliens: the 2d list of aliens in the wave [rectangular 2d list of Alien or None]
        _bolts:  the laser bolts currently on screen [list of Bolt, possibly empty]
        _dline:  the defensive line being protected [GPath]
        _lives:  the number of lives left  [int >= 0]
        _time:   The amount of time since the last Alien step [number >= 0]
        _numscore: score [int >=00]
    Update me later
    As you can see, all of these attributes are hidden.  You may find that you want to
    access an attribute in class Invaders. It is okay if you do, but you MAY NOT ACCESS
    THE ATTRIBUTES DIRECTLY. You must use a getter and/or setter for any attribute that
    you need to access in Invaders.  Only add the getters and setters that you need for
    Invaders. You can keep everything else hidden.

    You may change any of the attributes above as you see fit. For example, may want to
    keep track of the score.  You also might want some label objects to display the score
    and number of lives. If you make changes, please list the changes with the invariants.

    LIST MORE ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
        _direction: the direction the aliens are moving ["left" or "right"]
        _stepsUntilFire: the amount of steps before the aliens fire a bolt
        _countdown: attribute used to calculate when to fire
        _numwaves: the number of waves completed
        _soundOn: attribute whether or not sound is on or not
    """


    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def _getShip(self):
        """
        Returns: the ship object in this wave
        """
        return self._ship

    def _getLives(self):
        """
        Returns: the number of lives
        """
        return self._lives

    def _setaliens(self):
        """
        Initializes self._aliens as a 2d list of Alien objects
        """
    def _getScore(self):
        """
        Returns the score
        """
        return self._numscore
    def _setaliens(self):
        """
        Initializes self._aliens as a 2d list of Alien objects
        """
        counter = ALIEN_ROWS
        result = []
        for row in range(ALIEN_ROWS):
            templist = []
            if row == 0:
                y = GAME_HEIGHT-ALIEN_CEILING
            else:
                y = GAME_HEIGHT-ALIEN_CEILING-((ALIEN_HEIGHT+ALIEN_V_SEP)*row)
            for col in range(ALIENS_IN_ROW):
                if col == 0:
                    x = (ALIEN_H_SEP+ALIEN_WIDTH/2)
                else:
                    x = ALIEN_H_SEP+ALIEN_WIDTH/2+(ALIEN_WIDTH+ALIEN_H_SEP) *col
                if (counter % 6 == 2 or counter % 6 == 1):
                    templist.append(Alien(x,y,ALIEN_IMAGES[0]))
                elif (counter % 6 == 3 or counter % 6 == 4):
                    templist.append(Alien(x,y,ALIEN_IMAGES[1]))
                elif (counter % 6 == 5 or counter % 6 == 0):
                    templist.append(Alien(x,y,ALIEN_IMAGES[2]))
            result.append(templist)
            counter -=1
        self._aliens = result

    def _setship(self):
        """
        Initilizes self._ship
        """
        x = GAME_WIDTH / 2
        y = SHIP_BOTTOM
        self._ship = Ship(x,y,source = "ship.png")

    def _setDLine(self):
        """
        Initializes self._dline
        """

        pl = [0,DEFENSE_LINE,GAME_WIDTH,DEFENSE_LINE]
        self._dline = GPath(points = pl, linewidth = 2, linecolor = "black")

    # INITIALIZER (standard form) TO CREATE SHIP AND ALIENS
    def __init__(self):
        """
        Initializer: creates wave; sets initial values for attributes, creating
        the ship (Walker), aliens, and dline.

        Game begins at time 0 and no bolts initially. Direction is set to
        right initially, countdown until the alien fires to a random number, and
        3 lives. Speed of the alien is set to the constant ALIEN_SPEED.
        """
        self._setaliens()
        self._setship()
        self._setDLine()
        self._time = 0
        self._direction = "right"
        self._bolts = []
        self._stepsUntilFire = random.randrange(1,BOLT_RATE)
        self._countdown = self._stepsUntilFire
        self._lives = 3
        #self._numwaves = x
        self._speedalien = ALIEN_SPEED
        self._soundOn = True
        self._numscore = 0


    # UPDATE METHOD TO MOVE THE SHIP, ALIENS, AND LASER BOLTS
    def update(self,input,dt):
        """
        Update/moves ship, aliens, and bolts.

        Parameter input:  the user input to control the ship and change state
        Precondition: input is instance of GInput

        Parameter dt: seconds since last update
        Precondition: dt is a number (int or float)
        """

        self._time += dt
        if self._ship is not None:
            self._ship._moveShip(input)
        self._checkRightWall()
        self._checkLeftWall()
        self._march()
        self._alienFiring()
        self._shipFiring(input)
        if self._ship is not None:
            self._moveBolt()
        self._removeBolt()
        self._shipIsHit()
        self._alienIsHit()
        self._soundIsOn(input)
        self._soundIsOff(input)

    def _soundIsOff(self,input):
        """
        Enables sound to be played

        Parameter input: the input (inherited from GameApp)
        Precondition: [Ginput]
        """
        current = input.key_count
        change = current > 0
        if change == True and input.is_key_down("o"):
            self._soundOn = False

    def _soundIsOn(self,input):
        """
        Enables sound to be played

        Parameter input: the input (inherited from GameApp)
        Precondition: [Ginput]
        """
        current = input.key_count
        change = current > 0
        if change == True and input.is_key_down("p"):
            self._soundOn = True

    def _hitDLine(self):
        """
        Returns True if the aliens have reached the defensive Line
        """
        b = self._bottomAlien()
        if b <= DEFENSE_LINE:
            return True
        else:
            return False

    def _bottomAlien(self):
        """
        Returns the y value of the bottom most alien.
        """
        save = GAME_HEIGHT
        for row in self._aliens:
            for alien in row:
                if alien is not None:
                    if alien.y-ALIEN_HEIGHT/2 < save:
                        save = alien.y
        return save


    def _alienEmpty(self):
        """
        Returns True if all aliens have been eliminated: the 2d list of aliens
        is empty.
        """
        check = True
        for row in self._aliens:
            for alien in row:
                if alien is not None:
                    check = False
        return check


    def _shipIsHit(self):
        """
        Protocol for if the ship is hit by a bolt. Removes ship if hit and
        removes the bolt.
        """
        a = Sound('pop2.wav')
        b = Sound('pop1.wav')
        c = Sound('blast1.wav')
        list = [a,b,c]
        for bolt in self._bolts:
            if bolt is not None and self._ship is not None:
                if self._ship._collides(bolt):
                    if self._soundOn == True:
                        a = random.randrange(0,len(list))
                        list[a].play()
                    self._ship = None
                    self._lives -= 1
                    self._bolts.remove(bolt)


    def _alienIsHit(self):
        """
        Protocol for if the alien is hit by a bolt. Removes the alien hit and
        removes that specific bolt.
        """
        a = Sound('pop2.wav')
        b = Sound('pop1.wav')
        c = Sound('blast1.wav')
        list = [a,b,c]
        for bolt in self._bolts:
            for alien in range(len(self._aliens)):
                for x in range(len(self._aliens[alien])):
                    if self._aliens[alien][x] is not None:
                        if self._aliens[alien][x]._collides(bolt):
                            self._numscore += 5*(ALIEN_ROWS-x)
                            if self._soundOn == True:
                                a = random.randrange(0,len(list))
                                list[a].play()
                            self._aliens[alien][x] = None
                            bolt._bolttodelete = True
                            self._speedalien = self._speedalien * 0.97
        for bolt in self._bolts:
            if bolt._bolttodelete == True:
                self._bolts.remove(bolt)

    def _checkRightWall(self):
        """
        Checks if the aliens have collided with the right wall
        And makes them begin to move left
        """
        save = 0
        if self._direction == "right":
            for row in self._aliens:
                for alien in row:
                    if alien is not None:
                        if alien.x > save:
                            save = alien.x

            #if self._aliens[0][a].x + ALIEN_WIDTH/2 > GAME_WIDTH-ALIEN_H_SEP:
            if save + ALIEN_WIDTH/2 > GAME_WIDTH-ALIEN_H_SEP:
                for row in self._aliens:
                    for alien in row:
                        if alien is not None:
                            alien._movealiensY()
                self._direction = "left"

    def _checkLeftWall(self):
        """
        Checks if the aliens have collided with the left wall
        And makes them begin to move right
        """
        save = GAME_WIDTH
        if self._direction == "left":
            for row in self._aliens:
                for alien in row:
                    if alien is not None:
                        if alien.x < save:
                            save = alien.x

            if save - ALIEN_WIDTH/2 < ALIEN_H_SEP:
                for row in self._aliens:
                    for alien in row:
                        if alien is not None:
                            alien._movealiensY()
                self._direction = "right"

    def _march(self):
        """
        Marches the aliens across the screen.
        """
        if self._time > self._speedalien:
            for row in self._aliens:
                for alien in row:
                    if alien is not None:
                        alien._movealiensX(self._direction)
            self._countdown-=1
            self._time = 0
    def _checkcolumn(self,ac):
        """
        Returns False if the column is empty, true otherwise
        """

        for x in range(ALIEN_ROWS):
            if self._aliens[x][ac] is not None:
                return True
        return False

    def _alienFiring(self):
        """
        Selects a random alien in the bottom most row and fires a bolt from that
        alien. Aliens fire at a random rate.
        """
        a = Sound('pew2.wav')
        b = Sound('pew1.wav')
        list = [a,b]

        if self._countdown == 0:
            ac = random.randrange(0,ALIENS_IN_ROW-1)
            while self._checkcolumn(ac) == False:
                ac = random.randrange(0,ALIENS_IN_ROW-1)

            for x in range(ALIEN_ROWS):
                if self._aliens[x][ac] is not None:
                    bottom = self._aliens[x][ac]
            if self._soundOn == True:
                a = random.randrange(0,len(list))
                list[a].play()
            self._bolts.append(Bolt(bottom.x,bottom.y,False))
            self._stepsUntilFire = random.randrange(1,BOLT_RATE)
            self._countdown = self._stepsUntilFire

    def _shipFiring(self,input):
        """
        Allows the user/ship to shoot bolts if spacebar is pressed.
        """
        a = Sound('pew1.wav')
        b = Sound('pew2.wav')
        list = [a,b]
        current = input.key_count
        change = current > 0
        if change == True and input.is_key_down("spacebar"):
            check = False
            for bolt in self._bolts:
                if bolt._isPlayerBolt(bolt.directionUp):
                    check = True
            if check == False:
                if self._soundOn == True:
                    a = random.randrange(0,len(list))
                    list[a].play()
                self._bolts.append(Bolt(self._ship.x,SHIP_BOTTOM+SHIP_HEIGHT
                                        ,True))


    def _moveBolt(self):
        """
        Moves the bolt in the direction
        """
        for bolt in self._bolts:
            bolt._movebolt(self._ship.y,bolt.directionUp)

    def _removeBolt(self):
        """
        Removes the bolts
        """
        for bolt in self._bolts:
            if bolt._getY() > GAME_HEIGHT:
                self._bolts.remove(bolt)



    # DRAW METHOD TO DRAW THE SHIP, ALIENS, DEFENSIVE LINE AND BOLTS
    def draw(self,view):
        """
        Draws the ship, alien, defensive line, and bolts.

        Parameter view: the game view, used in drawing (see examples from class)
        Precondition: view is instance of GView
        """

        a = GLabel(text=str(self._numscore),x=30,y=650,font_size=30)
        a.draw(view)
        for row in self._aliens:
            for alien in row:
                if alien is not None:
                    alien.draw(view)
        if self._ship is not None:
            self._ship.draw(view)
        self._dline.draw(view)
        for bolt in self._bolts:
            bolt.draw(view)




    # HELPER METHODS FOR COLLISION DETECTION
